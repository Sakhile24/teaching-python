#Operators
'''
x= 10
y=2

#Addition
print(x+y)
#Subtraction
print(x-y)
#Multiplication
print(x*y)
#Division
print(x/y)
#Modulus
print(x%y)
print(5%2)
#Exponets
print(x**y)
'''
x=10
x+=2
print(x)
x-=2
print(x)