#Lists
#Use square brackets
fruits = ["Apple","Banana","Cherry"]
#to display each fruits

print(fruits[0])
print(fruits[1])
print(fruits[2])
#  Changing one fruit to another
fruits[1] ="Blueberry"
print(fruits)