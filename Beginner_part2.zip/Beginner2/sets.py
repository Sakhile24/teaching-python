#Sets
#Use curly brackets
'''
my_sets ={1,2,3,4,5}
print(my_sets)
#Add value
my_sets.add(6)
print(my_sets)

#remove a value
my_sets.remove(3)
print(my_sets)
'''

#Operation in set
set1 = {1,2,3}
set2 = {3,4,5}
#a. Union
union_set = set1.union(set2)
print(union_set)
#b. Intersection
inter_set = set1.intersection(set2)#Find the common element between the two set
print(inter_set)
#c. Difference
diff_set = set1.difference(set2)
print(diff_set)
#Q:When do we use set?
#A:Set are useful when you need to work with the collection of unique elements and perform operations like finding intersections, the differences or unions between sets. Some common use cases for sets include removing duplicate data from the list or collection, checking membership efficiently etc.