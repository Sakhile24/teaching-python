#Tuples
#Use round brackets
my_tuple =(1,2,3,4,5)
print(my_tuple)
#Display each index
print(my_tuple[0])
print(my_tuple[1])
print(my_tuple[2])
print(my_tuple[3])
print(my_tuple[4])
#using a negative index
print(my_tuple[-1])
#Using concat
tuple1 = (1,2,3)
tuple2= (4,5,6)
conc_tuple = tuple1 +tuple2
print(conc_tuple)
#Repetition
rep_tuple = tuple1 *3
print(rep_tuple)

#Tuples are used in a situation where you want to store a collection of elements that can not be changed throughout your program's execution.Some common uses for tuples include strong fixed collection of data such as coordinate, R,G,B codes, database records etc
