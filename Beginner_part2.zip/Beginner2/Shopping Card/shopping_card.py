#Question
#Create a shopping card programme that will continously ask the user for a foo product and price of the product 
#Have an exit clause if the user wishes to stop adding more things to their card
# At the end slow the food items and the total cost to the user
foods = []
prices =[]
total =0
while True :
    food =input("Enter a food to buy or press q to quit:")
    if food.lower() =='q':
        break
    else:
        price =float(input(f"Enter the price of the {food}: R"))
        foods.append(food)
        prices.append(price)
        
print("----- YOUR CART -----")

for i in range(len(prices)):
    print(f"{foods[i]} = R{prices[i]:.2f}")
total = sum(prices)
print(f"\nYour total is :R{total:.2f}")