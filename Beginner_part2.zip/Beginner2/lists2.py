#List2
#Square Brackets
fruits =["apple","banana","cherry"]
#Add one value
fruits.append("Kiwi")
print(fruits)
#Add a value in between Apple and banana
fruits.insert(1,"orange")
print(fruits)
#Remove an item
fruits.remove("Kiwi")
print(fruits) 
#Sorting method in ascending
fruits.sort()
print(fruits)
#sorting method in descending
fruits.sort(reverse= True)
print(fruits)