#Dictionary
my_dict ={'Apple' :3, 'Banana':5,'Orange':2}
print(my_dict['Apple'])
#Add new entre
my_dict['Grape'] =4
print(my_dict)
#Modify an existing
my_dict['Banana'] =7
print(my_dict)