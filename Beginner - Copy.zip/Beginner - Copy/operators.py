#ARITHMETICS OPERATORS
# Addition(+)
# Subtraction(-)
# Multiplication(*)
# Divison(/)
# Modulus(%)
# Exponent(**)
x= 10
y = 2
#Addition
print(x+y)

#Subtraction
print(x-y)

#Multiplication
print(x*y)

#Division
print(x/y)

#Modulus
print(x%y)
print(5%2)
#Exponent
print(x**y)

x +=2
print(x)
x-=2
print(x)



