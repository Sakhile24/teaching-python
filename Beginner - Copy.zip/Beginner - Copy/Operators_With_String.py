# Operators Using Strings

str1 = "Hello"
str2 = "World!"
print(str1 + " " + str2)
#Multiplication of 1 string
print(str1*3)
