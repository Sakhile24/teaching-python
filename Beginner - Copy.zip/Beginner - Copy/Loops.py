#Loops

#For loop
fruits = ["Apple","Banana","Grapes"]
for fruit in fruits:
    print(fruit)
    break
    
numbers = [3,4,5,6,7,8]
for num in numbers:
    print(num)
    break
print()    
#While Loops
#Using a while loop to count 1 to 5
count =1
while count<=5:
    print(count)
    count+=1    #increment by 1