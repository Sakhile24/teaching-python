#Control Statement Using Loops
#For Loops
vegetables = ["Tomato","Potato","Onion","Cabbage","Spinach"]
for veg in vegetables:
    if veg =="Spinach":
        break   #Exit loop if Potato is found
    print(veg)
print()
for veg in vegetables:
    if veg =="Tomato":
        continue    #Skips Tomato and moves to the  iteration
    print(veg)
print()
for veg in vegetables:
    if veg =="Cabbage":
        pass   #Placeholder, No action is needed for Cabbage
    print(veg)
print()
#While loops
count =0
while count <5:
    print(count)
    count +=1
    if count ==3:
        break # Exit loop when the  count is reached 
