#number
num = 3
print(num)
print(type(num))
num2 =3.14
print(num2)
print(type(num2))