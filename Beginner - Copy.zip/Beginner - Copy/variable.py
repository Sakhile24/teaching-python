#variables


#valid variable names
my_variable =10 
total_count =0 
user = 'Sakhile' 

#invalid variable names
second_variable =10
user_name = 'Sipho' 

