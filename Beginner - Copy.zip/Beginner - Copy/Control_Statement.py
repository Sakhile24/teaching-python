#Control Statement

num =0
if num>0:
    print("This number is positive")
elif num ==0:
    print("The number is zero")
else :
    print("This number is negative number")