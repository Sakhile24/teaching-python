#String
message = """Bob's world is cool"""

print(message)
