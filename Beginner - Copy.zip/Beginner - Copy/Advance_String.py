#Advance_Strings
message = " Hello, World "
print(message.strip())
print(message.lower())
print(message.split(','))
print(message.upper())
print(message.replace("Hello,","Bob's"))